import numpy as np
arr=np.array([10,20,30])
print(arr+5)
print(arr*2)
print(arr**2)
print(arr/2)
print(arr%3)
 