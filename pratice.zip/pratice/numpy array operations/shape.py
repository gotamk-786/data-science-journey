import numpy as np


arr_2d=np.array([[1,2,3],
                 [4,5,6]])
print(arr_2d.shape)#--> shape help to find dimension of array
