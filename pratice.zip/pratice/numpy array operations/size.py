#find total number of element in the array .size return karta yhe jab hum bhota larger data pe kam karty to 
#size humein bataye ga kitni data ha
import numpy as np
arr=np.array([[10,20,30,40],[50,60,70,80]])
print(arr.size)