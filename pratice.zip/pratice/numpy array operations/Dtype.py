import numpy as np
arr=np.array([10,20,30.5,40])
print(arr.dtype)
# dtype used to find data type konsa ha
  