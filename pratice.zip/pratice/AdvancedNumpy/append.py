# eleent add at the end

import numpy as np
arr=np.array([10,20,30])
new_arr=np.append(arr,[40,50,60])
print(new_arr)
