#fancy indexing means selecting multiple elements at once
import numpy as np
arr=np.array([10,20,30,40,50,60])
print(arr[[0,2,4]])
#10,30,50