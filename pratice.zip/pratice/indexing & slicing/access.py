import numpy as np
"""
array[index] #1D array
array[row,column] #2D
 """
arr=np.array([10,20,30,40,50])
print(arr[0]) # first element

"""
print(arr[2]) #20 0 based 
print(arr[-1]) # last element

"""