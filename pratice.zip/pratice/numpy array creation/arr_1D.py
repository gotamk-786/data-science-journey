#1d array in numpy
import numpy as np
arr_1D=np.array([1,2,3,4,5])
print("array 1D:",arr_1D)