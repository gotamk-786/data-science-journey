# Multidimentional array
#matrix ---->2D --->array number store row ^=& colums
import numpy as np
matrix=np.array([
    [1,2,3,4,5],
    [8,9,10,11,12],
    [11,12,13,14,15]
])
print("matrix:",matrix)
