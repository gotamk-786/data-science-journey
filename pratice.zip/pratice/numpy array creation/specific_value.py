#full(shape,value) ---->for specific value
import numpy as np
filled_array=np.full((3,2),7) #----> here 2,2 dimension ha and 7 jo digit hum fill kar rhy wo
print("filled_array:",filled_array)
