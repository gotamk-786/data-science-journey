#creting sequence of numbers in numpy
#arange(start,stop,step)--->step means kitna gap hona chiaye number k beech
import numpy as np
arr=np.arange(1,10,1)
print("arr sequence :",arr)
