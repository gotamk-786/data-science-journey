#creating identity matrix
#eye(size)

import numpy as np
identity_matrix=np.eye(3) #--- yha 3 is demension of matrix hai 
print("identity matrix:",identity_matrix)
