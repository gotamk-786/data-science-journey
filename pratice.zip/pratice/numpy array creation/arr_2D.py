import numpy as np
#2D array in numpy same as 1D array is mein multiple 1D array hogi
arr_2D=np.array([1,2,3],
                [4,5,6],
                [7,8,9])
print("2D array:",arr_2D)