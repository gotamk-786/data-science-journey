# with default values used zero function for future value
#np.zero(shape) (3) for 1D,2D,(3,3)

import numpy as np
zero_array=np.zeros((3,2))
print(zero_array)

