#ones (shape) --->(1 value)

import numpy as np
ones_array=np.ones((2,3))
print("ones array:",ones_array)